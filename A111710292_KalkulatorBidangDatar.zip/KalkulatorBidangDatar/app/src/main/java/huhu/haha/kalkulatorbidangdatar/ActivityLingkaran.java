package huhu.haha.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ActivityLingkaran extends AppCompatActivity {

    EditText DiameterLingkaran;
    TextView HasilLingkaran;
    Button BtLuasLingkaran, BtKelLingkaran;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lingkaran);

        DiameterLingkaran = findViewById(R.id.diameter_lingkaran);
        HasilLingkaran = findViewById(R.id.lingkaranhasil);
        BtKelLingkaran = findViewById(R.id.btnKelLingkaran);
        BtLuasLingkaran = findViewById(R.id.btnLuaslingkaran);

        BtLuasLingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double r, diameter, hasil;
                diameter = Double.valueOf(DiameterLingkaran.getText().toString().trim());
                r = diameter/2;
                hasil = 3.14*r*r;
                String mhasil = String.valueOf(hasil);
                HasilLingkaran.setText(mhasil);
            }
        });

        BtKelLingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double diameter, hasil;
                diameter = Double.valueOf(DiameterLingkaran.getText().toString().trim());
                hasil = 3.14*diameter;
                String mhasil = String.valueOf(hasil);
                HasilLingkaran.setText(mhasil);
            }
        });

    }
}