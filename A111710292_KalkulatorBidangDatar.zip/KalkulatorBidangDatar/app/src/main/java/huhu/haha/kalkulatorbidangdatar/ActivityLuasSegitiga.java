package huhu.haha.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ActivityLuasSegitiga extends AppCompatActivity {

    EditText Alas, Tinggi;
    TextView HasilLSegitiga;
    Button ButtonLSegitiga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_luas_segitiga);

        Alas = findViewById(R.id.alas_segitiga);
        Tinggi = findViewById(R.id.tinggi_segitiga);
        HasilLSegitiga = findViewById(R.id.segitigalhasil);
        ButtonLSegitiga = findViewById(R.id.btnLuassegitiga);

        ButtonLSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double alas, tinggi, hasil;
                alas = Double.valueOf(Alas.getText().toString().trim());
                tinggi = Double.valueOf(Tinggi.getText().toString().trim());
                hasil = alas/2 * tinggi;
                String mhasil = String.valueOf(hasil);
                HasilLSegitiga.setText(mhasil);
            }
        });

    }
}