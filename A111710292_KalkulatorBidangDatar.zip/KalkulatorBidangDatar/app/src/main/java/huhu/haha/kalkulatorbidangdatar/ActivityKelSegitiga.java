package huhu.haha.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class ActivityKelSegitiga extends AppCompatActivity {

    EditText sisi1, sisi2, sisi3;
    TextView HasilKSegitiga;
    Button ButtonKSegitiga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kel_segitiga);

        sisi1 = findViewById(R.id.s1_segitiga);
        sisi2 = findViewById(R.id.s2_segitiga);
        sisi3 = findViewById(R.id.s3_segitiga);
        HasilKSegitiga = findViewById(R.id.segitigakhasil);
        ButtonKSegitiga = findViewById(R.id.btnkelsegitiga);

        ButtonKSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double s1,s2,s3, hasil;
                s1 = Double.valueOf(sisi1.getText().toString().trim());
                s2 = Double.valueOf(sisi2.getText().toString().trim());
                s3 = Double.valueOf(sisi3.getText().toString().trim());
                hasil = s1+s2+s3;
                String mhasil = String.valueOf(hasil);
                HasilKSegitiga.setText(mhasil);
            }
        });

    }
}