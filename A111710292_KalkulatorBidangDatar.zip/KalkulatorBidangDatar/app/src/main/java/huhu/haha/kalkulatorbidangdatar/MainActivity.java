package huhu.haha.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button buttonExit;
    Button buttonPersegi;
    Button buttonSegitiga;
    Button buttonLingkaran;
    float v=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonExit = findViewById(R.id.btnExit);
        buttonPersegi = findViewById(R.id.btnPersegi);
        buttonSegitiga = findViewById(R.id.btnSegitiga);
        buttonLingkaran = findViewById(R.id.btnLingkaran);

        buttonPersegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityPersegi();
            }
        });

        buttonExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moveTaskToBack(true);
                android.os.Process.killProcess(android.os.Process.myPid());

                System.exit(1);
            }
        });

        buttonSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivitySegitiga();
            }
        });

        buttonLingkaran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityLingkaran();
            }
        });



        buttonPersegi.setTranslationY(800);
        buttonSegitiga.setTranslationY(800);
        buttonLingkaran.setTranslationY(800);
        buttonExit.setTranslationY(800);

        buttonPersegi.setAlpha(v);
        buttonSegitiga.setAlpha(v);
        buttonLingkaran.setAlpha(v);
        buttonExit.setAlpha(v);

        buttonPersegi.animate().translationY(0).alpha(1).setDuration(800).setStartDelay(300).start();
        buttonSegitiga.animate().translationY(0).alpha(1).setDuration(800).setStartDelay(300).start();
        buttonLingkaran.animate().translationY(0).alpha(1).setDuration(800).setStartDelay(500).start();
        buttonExit.animate().translationY(0).alpha(1).setDuration(800).setStartDelay(500).start();

    }

    public void openActivityPersegi(){
        Intent intent = new Intent(this, ActivityPersegi.class);
                startActivity(intent);
    }

    public void openActivitySegitiga(){
        Intent intent = new Intent(this, ActivitySegitiga.class);
                startActivity(intent);
    }

    public void openActivityLingkaran(){
        Intent intent = new Intent(this, ActivityLingkaran.class);
                startActivity(intent);
    }
}