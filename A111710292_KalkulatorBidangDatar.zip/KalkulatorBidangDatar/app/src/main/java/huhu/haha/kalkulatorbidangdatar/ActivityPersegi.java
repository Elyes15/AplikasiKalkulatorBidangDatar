package huhu.haha.kalkulatorbidangdatar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class ActivityPersegi extends AppCompatActivity {

    EditText PjgPersegi, LbrPersegi;
    Button BtluasPersegi, BtkelPersegi;
    TextView HasilPersegi;

    float v=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_persegi);

        PjgPersegi = findViewById(R.id.pjg_persegi);
        LbrPersegi = findViewById(R.id.lbr_persegi);
        BtluasPersegi = findViewById(R.id.btnLuaspersegi);
        BtkelPersegi = findViewById(R.id.btnKelpersegi);
        HasilPersegi = findViewById(R.id.persegihasil);

        BtluasPersegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double pjg, lbr, hasil;
                pjg = Double.valueOf(PjgPersegi.getText().toString().trim());
                lbr = Double.valueOf(LbrPersegi.getText().toString().trim());
                hasil = pjg*lbr;
                String mhasil = String.valueOf(hasil);
                HasilPersegi.setText(mhasil);
            }
        });

        BtkelPersegi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double pjg, lbr, hasil;
                pjg = Double.valueOf(PjgPersegi.getText().toString().trim());
                lbr = Double.valueOf(LbrPersegi.getText().toString().trim());
                hasil = (2*pjg) + (2*lbr);
                String mhasil = String.valueOf(hasil);
                HasilPersegi.setText(mhasil);
            }
        });

    }
}