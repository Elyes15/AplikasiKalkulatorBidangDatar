package huhu.haha.kalkulatorbidangdatar;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;
import java.util.List;

public class ActivitySegitiga extends AppCompatActivity {

    Button buttonLSegitiga;
    Button buttonKSegitiga;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segitiga);

        buttonKSegitiga = findViewById(R.id.btnksegitiga);
        buttonLSegitiga = findViewById(R.id.btnlsegitiga);

        buttonLSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityLuasSegitiga();
            }
        });

        buttonKSegitiga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openActivityKelSegitiga();
            }
        });



    }

    public void openActivityLuasSegitiga() {
        Intent intent = new Intent(this, ActivityLuasSegitiga.class);
        startActivity(intent);
    }
    public void openActivityKelSegitiga() {
        Intent intent = new Intent(this, ActivityKelSegitiga.class);
        startActivity(intent);
    }
}